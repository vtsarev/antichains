function antichains(вершины,рёбра) {
		var ребра = рёбра.map((v,i)=>[вершины.indexOf(рёбра[i][0]),вершины.indexOf(рёбра[i][1])]);
		var индверш = вершины.map((v,i)=>i);
		var индверш0 = ребра.map((v,i)=>ребра[i][0]);
		var индверш1 = ребра.map((v,i)=>ребра[i][1]);
		var next = индверш.map(v1=>индверш1.filter((v2,i2)=>(v1==индверш0[i2])));
		var prev=индверш.map(v1=>индверш0.filter((v2,i2)=>(v1==индверш1[i2])));
		var Пцепочки=[],Пцепочка,n,v,vv=индверш.slice(),Пцепочка_вершины=[],c=0,ц;ребраПЦ=[];
			while(vv.length>0) {
				Пцепочка=[v=vv.shift()];Пцепочка_вершины[v]=c;
				while(((n=next[v].slice()).length==1)&&(prev[v=n[0]].length==1)) {
					Пцепочка.push(v);Пцепочка_вершины[v]=c;vv.splice(vv.indexOf(v),1);
				}
				Пцепочки.push(Пцепочка);c++;
			}
			индЦ=Пцепочки.map((v,i)=>i);ПцепочкиВ=Пцепочки.map(cc=>cc.map(c=>вершины[c]));
			var следЦ=Пцепочки.map(cc=>next[cc.slice(-1)[0]].map(v=>Пцепочка_вершины[v]));
			предЦ=Пцепочки.map(cc=>prev[cc[0]].map(v=>Пцепочка_вершины[v]));
			ребраПЦ=следЦ.reduce((ребра,nc,ic)=>ребра.concat(nc.map(c=>[ic,c])),[]);
		metachains();
		var кмц=метацепочки.length;
		var квг=индЦ.length;
		var номМЦ=[];метацепочки.forEach((МЦ,i)=>МЦ.forEach(в=>(номМЦ[в]=i)));
		var вектор_коды_метацепочек=индЦ.map((cc,i)=>метацепочки.map((c,j)=>-1));
			for(var i=0;i<квг;i++) {
				for(var j=0;j<кмц;j++) {
					for(var s=метацепочки[j].length-1;s>=0;s--) {
						if(вектор_коды[i][метацепочки[j][s]]>-1) {
							вектор_коды_метацепочек[i][j]=s;
							break;
						}
					}
				}
			}
			var P=[[0]];var L=[(new Array(кмц)).fill(-1)];
			for(var i=1;i<квг;i++) {
				var k=номМЦ[i];
					var S=вектор_коды_метацепочек[i].map(a=>a);
					S[k]--;
				L=ILMA(L,S);
			}		function ILMA(L,S) {
					var W, L1=L.map(a=>a.map(b=>b));
					if(!L.some(вк=>S.every((kk,ik)=>вк[ik]==kk))) {
						L1.push(S);
						for(W of L) {
							var max_vec=W.map((a,j)=>Math.max(a,S[j]));
							if(!L1.some(вк1=>max_vec.every((k,jk)=>вк1[jk]==k))) {
								L1.push(max_vec);
							}
						}
					}
				return L1;
		}

			MA=[];var MAmax=0;
			for(var i=0;i<L.length;i++) {
				var A=[];
				for(var j=0;j<L[i].length;j++) {
					var r=L[i][j]+1;
					if(r<метацепочки[j].length) {
						var ка=метацепочки[j][r];
						if((A.length==0) || (A.every(va=>(вектор_коды[ка][va]==-1)))) {
							A.push(ка);
						}
					}
				}
				if(A.length>0) {
					MA.push(A.slice());MAmax=Math.max(MAmax,A.length);
				}
			}
			var MA2=MA.map(a=>a.map(b=>b));
				for(var i=0;i<MA.length;i++) {
					var A=MA[i];
					MA[i]=A.filter(va=>(A.every(va1=>(va1==va)||(вектор_коды[va][va1]==-1))));
				}
			MA=MA.map(mm=>mm.sort(function(a, b){return a-b}));		function cartesianProduct(arr) {
				return arr.reduce((a,b)=>a.map(x=>b.map(y=>x.concat(y))).reduce((a,b)=>a.concat(b),[]),[[]]);
		}

				var сечения=[];
				for(var i=0;i<MA.length;i++) {
					цепочки=MA[i].map(вц=>ПцепочкиВ[вц]);
					сечения=сечения.concat(cartesianProduct(цепочки));
							
				}
			return сечения;
					
}
