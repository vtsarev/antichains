function metachains() {
		
		вектор_коды=индЦ.map((cc,i)=>индЦ.map((c,j)=>(i==j)?0:-1));
		вектор_коды.forEach(function (строка,i,s){
		
			вектор_коды[i]=[вектор_коды[i]].concat(предЦ[i].map(pr=>вектор_коды[pr])).reduce((максвек,вектор)=> вектор.map((vk,ik)=>Math.max(vk,максвек[ik])));
			
				});
		var g = [];
			for(var i=0;i<индЦ.length;i++) {
				g1 = [];
				for(var j=i+1;j<индЦ.length;j++) {
					if(вектор_коды[j][i] > -1) {
						g1.push(j);
					}
				}
				g.push(g1.slice());
			}
			var n=индЦ.length,used;
				var mt=индЦ.map(c=>-1);
			for(var i=0;i<n;i++) {
				used=индЦ.map(c=>false);
				try_kuhn(i);
			}		function try_kuhn(v) {
				if(used[v]) {
					return false;
				}
				used[v] = true;
				for(var i=0;i<g[v].length;i++) {
					var to=g[v][i];
					if(mt[to] == -1 || try_kuhn(mt[to])) {
						mt[to]=v;
						return true;
					}
				}
				return false;
		}

			var mt0=mt.map(c=>false);
			var mt1=mt.map(c=>-1);
				for(var i=0;i<mt.length;i++) {
					if(mt[i]>-1) {
						mt1[mt[i]] = i;
						mt0[i]=true;mt0[mt[i]]=true;
					}
				}
				var mt11=mt1.slice();
			метацепочки=[];
				for(var i=0;i<mt1.length;i++) {
					if(mt1[i]>-1) {
						var мц=[];
						мц.push(i);
						var k=i;
						while(mt1[k]>-1) {
							var k1=mt1[k];
							мц.push(k1);
							mt1[k]=-1;
							k=k1;
						}
						метацепочки.push(мц.slice());
					}
				}
				for(var i=0;i<mt0.length;i++) {
					if(mt0[i]==false) {
						метацепочки.push([i]);
					}
				}
}
