		function TopoSort(){
			text='',вершины=[],упорядочено=true,Nвер=Nodes.length,Nреб=рёбра.length,ребра=[],Nvisited=0;
			ребра.length=Nреб;var AdjList=[];AdjList.length=Nвер;AdjList.fill(0,0,Nвер);
			for(var i=0;i<Nреб;i++) {
				ребра[i]=[];ребра[i][0]=Nodes.indexOf(рёбра[i][0]); ++AdjList[ребра[i][1]=Nodes.indexOf(рёбра[i][1])];
				if(ребра[i][0]==ребра[i][1]) {text += '// Самозамкнутое ребро '+JSON.stringify(рёбра[i])+', топологическая сортировка невозможна.'; return;};
				if(ребра[i][0] > ребра[i][1]) {упорядочено=false;};
			};
			var set0=[];
			for(var i=0; i < Nвер; i++) {
				if(AdjList[i]==0) {set0.push(i);};
			};
			while(set0.length > 0) {
				Nvisited++;var n=set0.shift();
				вершины.push(Nodes[n]);
				for(var i=0; i < Nреб; i++) {
					if(ребра[i][0]==n) {
						if(--AdjList[ребра[i][1]]<=0) {set0.push(ребра[i][1]);};
					};
				};
			};
			if(вершины.length < Nвер) {text+='// Имеется один или несколько циклов, топологическая сортировка невозможна.'; return;};
		}
