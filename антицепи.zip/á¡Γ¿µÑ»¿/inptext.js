		var рёбра=[],Nodes,вершины,text='',индЦ,предЦ,метацепочки,MA,ПцепочкиВ,ребраПЦ,цепочки,вектор_коды,антицепи;
		function inptext(){
			if(event.target.id=="" && !event.target.open){
				document.getElementById("input_edges").innerHTML=document.getElementById("input_edges").value;
			}
			if(event.target.id=="" && event.target.open){
				рёбра=eval(document.getElementById("input_edges").value);
				Nodes=рёбра.reduce((vv,r)=>vv.concat(r.filter(v=>!vv.includes(v))),[]);
				TopoSort();
				document.getElementById('graphviz_svg').innerHTML=text;
				if(text==''){
					антицепи=antichains(вершины,рёбра);
					var gdata1='digraph G {'+рёбра.reduce((a,b)=>(a+b[0]+'->'+b[1]+';'),'')+'}';
					var gdata2='digraph G {'+ребраПЦ.reduce((a,b)=>(a+b[0]+'->'+b[1]+';'),'')+'}';
					document.getElementById('graphviz_svg').innerHTML+=Viz(gdata1, 'svg')+Viz(gdata2, 'svg');
					Array.from(document.getElementsByTagName("details")).forEach(
						d=>((d.id=='')?0:(d.childNodes[0].setAttribute("value",eval(d.id).length),
						d.childNodes[1].nodeValue=JSON.stringify(eval(d.id))))
						);
				}
			}
		}
